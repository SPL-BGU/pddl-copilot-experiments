# iss024d-e2e vs sweep5v2-live — tool-verified parity

Generated 2026-07-17 by `tools/iss024d_parity.py`.

- filters: think=on, cond=tools_all_minimal, neutral bank v11-13 pooled; TOST margin ±5pp at α=.05 (90% Newcombe CI, z=1.6449)
- iss024d root: /Users/omereliyahu/personal/pddl-copilot-experiments/results/iss024d-e2e-live  (cells=5, dup=0, infra-excluded=0)
- baseline root: /Users/omereliyahu/personal/pddl-copilot-experiments/results/sweep5v2-live  (cells=5, dup=0, infra-excluded=0)

### Gemma negative control (evaluated first — zero generative delta, calibrates the noise floor)

| model | task | n(iss) | p(iss) | n(base) | p(base) | Δpp | 90% CI (pp) | TOST |
|---|---|---|---|---|---|---|---|---|
| gemma4_26b-a4b | validate_domain | 360 | 52.2 | 360 | 51.1 | +1.1 | [-5.0, +7.2] | FAIL |
| gemma4_26b-a4b | validate_problem | 600 | 55.8 | 600 | 55.5 | +0.3 | [-4.4, +5.0] | FAIL |
| gemma4_26b-a4b | validate_plan | 3000 | 0.9 | 3000 | 0.6 | +0.3 | [-0.1, +0.7] | PASS |
| gemma4_26b-a4b | solve | 300 | 17.7 | 300 | 23.0 | -5.3 | [-10.7, +0.1] | FAIL |
| gemma4_26b-a4b | simulate | 300 | 44.0 | 300 | 44.0 | +0.0 | [-6.6, +6.6] | FAIL |

### Qwen primary set (parser-off is the one generative delta)

| model | task | n(iss) | p(iss) | n(base) | p(base) | Δpp | 90% CI (pp) | TOST |
|---|---|---|---|---|---|---|---|---|
| Qwen3_5_0_8B | validate_domain | 360 | 87.5 | 360 | 84.2 | +3.3 | [-1.0, +7.6] | FAIL (≤ control noise floor) |
| Qwen3_5_0_8B | validate_problem | 600 | 14.3 | 600 | 14.0 | +0.3 | [-3.0, +3.7] | PASS |
| Qwen3_5_0_8B | validate_plan | 3000 | 20.4 | 3000 | 17.3 | +3.1 | [+1.5, +4.8] | PASS |
| Qwen3_5_0_8B | solve | 300 | 10.3 | 300 | 11.7 | -1.3 | [-5.6, +2.9] | FAIL (≤ control noise floor) |
| Qwen3_5_0_8B | simulate | 300 | 1.7 | 300 | 5.0 | -3.3 | [-6.0, -0.9] | FAIL (≤ control noise floor) |
| Qwen3_5_4B | validate_domain | 360 | 96.1 | 360 | 95.8 | +0.3 | [-2.2, +2.8] | PASS |
| Qwen3_5_4B | validate_problem | 600 | 82.7 | 600 | 76.8 | +5.8 | [+2.0, +9.6] | FAIL |
| Qwen3_5_4B | validate_plan | 3000 | 80.9 | 3000 | 75.6 | +5.3 | [+3.6, +7.1] | FAIL (≤ control noise floor) |
| Qwen3_5_4B | solve | 300 | 59.0 | 300 | 67.7 | -8.7 | [-15.0, -2.2] | FAIL |
| Qwen3_5_4B | simulate | 300 | 63.0 | 300 | 63.7 | -0.7 | [-7.1, +5.8] | FAIL (≤ control noise floor) |
| Qwen3_5_9B | validate_domain | 360 | 99.4 | 360 | 98.9 | +0.6 | [-0.7, +1.9] | PASS |
| Qwen3_5_9B | validate_problem | 600 | 93.8 | 600 | 91.0 | +2.8 | [+0.3, +5.4] | FAIL (≤ control noise floor) |
| Qwen3_5_9B | validate_plan | 3000 | 59.5 | 3000 | 65.3 | -5.7 | [-7.8, -3.7] | FAIL |
| Qwen3_5_9B | solve | 300 | 50.3 | 300 | 57.7 | -7.3 | [-13.9, -0.6] | FAIL |
| Qwen3_5_9B | simulate | 300 | 82.7 | 300 | 84.0 | -1.3 | [-6.3, +3.7] | FAIL (≤ control noise floor) |
| qwen3_6_35b | validate_domain | 360 | 98.1 | 360 | 99.7 | -1.7 | [-3.3, -0.4] | PASS |
| qwen3_6_35b | validate_problem | 600 | 96.7 | 600 | 98.2 | -1.5 | [-3.1, +0.0] | PASS |
| qwen3_6_35b | validate_plan | 3000 | 98.0 | 3000 | 98.6 | -0.6 | [-1.2, -0.0] | PASS |
| qwen3_6_35b | solve | 300 | 67.0 | 300 | 78.3 | -11.3 | [-17.2, -5.4] | FAIL |
| qwen3_6_35b | simulate | 300 | 92.3 | 300 | 95.7 | -3.3 | [-6.6, -0.1] | FAIL (≤ control noise floor) |

### Decision

DECISION RULE (complete 25-cell table): gemma control 1/5 pass (noise floor F = 5.3pp); Qwen 7/20 pass, max |Δ| = 11.3pp
JOB-LEVEL PARITY: FAILS (rule: ≥18/20 Qwen pass AND no Qwen |Δ| > 10pp)
Per prereg rule 4: report iss024d as a separate-apparatus replication, clearly labeled; never as 'the sweep5v2 cells resolved'. No margin adjustment.
Failing cells (if any) need a mechanism decomposition (secondary endpoints) before any headline use — prereg rule 3.
Interpretation language (binding): iss024d numbers are 'independent rerun estimates under full-response storage', never 'the resolved exact value of' a censored sweep5v2 cell. Exact e2e is think=on-scoped.

### Secondary (neutral bank, descriptive): format_parse_fail and truncated rate deltas

| model | task | fpf(iss) | fpf(base) | Δfpf pp | trunc(iss) | trunc(base) | Δtrunc pp |
|---|---|---|---|---|---|---|---|
| gemma4_26b-a4b | validate_domain | 0.0 | 0.0 | +0.0 | 45.0 | 46.1 | -1.1 |
| gemma4_26b-a4b | validate_problem | 0.0 | 0.0 | +0.0 | 39.5 | 37.8 | +1.7 |
| gemma4_26b-a4b | validate_plan | 0.0 | 0.0 | +0.0 | 68.4 | 67.5 | +0.9 |
| gemma4_26b-a4b | solve | 0.0 | 0.0 | +0.0 | 72.0 | 70.0 | +2.0 |
| gemma4_26b-a4b | simulate | 0.0 | 0.0 | +0.0 | 84.0 | 83.3 | +0.7 |
| Qwen3_5_0_8B | validate_domain | 0.0 | 0.0 | +0.0 | 20.8 | 19.2 | +1.7 |
| Qwen3_5_0_8B | validate_problem | 0.0 | 0.0 | +0.0 | 84.0 | 85.8 | -1.8 |
| Qwen3_5_0_8B | validate_plan | 0.0 | 0.0 | +0.0 | 91.3 | 88.4 | +3.0 |
| Qwen3_5_0_8B | solve | 0.0 | 0.0 | +0.0 | 95.3 | 93.7 | +1.7 |
| Qwen3_5_0_8B | simulate | 0.0 | 0.0 | +0.0 | 95.7 | 95.0 | +0.7 |
| Qwen3_5_4B | validate_domain | 0.0 | 0.0 | +0.0 | 6.4 | 2.5 | +3.9 |
| Qwen3_5_4B | validate_problem | 0.0 | 0.0 | +0.0 | 28.2 | 28.0 | +0.2 |
| Qwen3_5_4B | validate_plan | 0.0 | 0.0 | +0.0 | 43.5 | 42.5 | +1.1 |
| Qwen3_5_4B | solve | 0.0 | 0.0 | +0.0 | 81.0 | 65.0 | +16.0 |
| Qwen3_5_4B | simulate | 0.0 | 0.0 | +0.0 | 82.3 | 79.0 | +3.3 |
| Qwen3_5_9B | validate_domain | 0.0 | 0.0 | +0.0 | 1.4 | 3.9 | -2.5 |
| Qwen3_5_9B | validate_problem | 0.0 | 0.0 | +0.0 | 6.3 | 7.3 | -1.0 |
| Qwen3_5_9B | validate_plan | 0.0 | 0.0 | +0.0 | 37.7 | 26.3 | +11.3 |
| Qwen3_5_9B | solve | 0.0 | 0.0 | +0.0 | 85.7 | 67.0 | +18.7 |
| Qwen3_5_9B | simulate | 0.0 | 0.0 | +0.0 | 76.0 | 75.0 | +1.0 |
| qwen3_6_35b | validate_domain | 0.0 | 0.0 | +0.0 | 0.0 | 0.6 | -0.6 |
| qwen3_6_35b | validate_problem | 0.0 | 0.0 | +0.0 | 0.7 | 3.8 | -3.2 |
| qwen3_6_35b | validate_plan | 0.0 | 0.0 | +0.0 | 19.5 | 9.2 | +10.3 |
| qwen3_6_35b | solve | 0.0 | 0.0 | +0.0 | 56.7 | 44.0 | +12.7 |
| qwen3_6_35b | simulate | 0.0 | 0.0 | +0.0 | 78.3 | 80.3 | -2.0 |

### Per-variant success delta (iss − base, pp; full v11-16 bank, descriptive; * = steered, diagnostic-only)

| model | task | v11 | v12 | v13 | v14* | v15* | v16* |
|---|---|---|---|---|---|---|---|
| gemma4_26b-a4b | validate_domain | +0.8 | +5.8 | -3.3 | +0.0 | +0.8 | -10.8 |
| gemma4_26b-a4b | validate_problem | +2.5 | -1.5 | +0.0 | -0.5 | +4.5 | +4.5 |
| gemma4_26b-a4b | validate_plan | +0.4 | +0.4 | +0.0 | -0.8 | +0.4 | -1.1 |
| gemma4_26b-a4b | solve | -6.0 | -11.0 | +1.0 | +2.0 | +3.0 | -4.0 |
| gemma4_26b-a4b | simulate | +0.0 | +3.0 | -3.0 | +3.0 | +2.0 | -2.0 |
| Qwen3_5_0_8B | validate_domain | -0.8 | +7.5 | +3.3 | +1.7 | +2.5 | +0.0 |
| Qwen3_5_0_8B | validate_problem | -2.0 | +2.0 | +1.0 | +4.5 | +0.0 | -1.0 |
| Qwen3_5_0_8B | validate_plan | +2.3 | +5.6 | +1.5 | +0.2 | +6.6 | -0.9 |
| Qwen3_5_0_8B | solve | +0.0 | -1.0 | -3.0 | -10.0 | -5.0 | +0.0 |
| Qwen3_5_0_8B | simulate | -9.0 | +1.0 | -2.0 | +1.0 | +2.0 | +2.0 |
| Qwen3_5_4B | validate_domain | +3.3 | +0.8 | -3.3 | +0.8 | -0.8 | -8.3 |
| Qwen3_5_4B | validate_problem | +6.0 | +7.0 | +4.5 | +8.0 | +2.5 | +6.0 |
| Qwen3_5_4B | validate_plan | +6.3 | +2.1 | +7.6 | +3.3 | +8.0 | +7.2 |
| Qwen3_5_4B | solve | -14.0 | -5.0 | -7.0 | -10.0 | +5.0 | -14.0 |
| Qwen3_5_4B | simulate | +3.0 | +0.0 | -5.0 | +0.0 | -5.0 | +1.0 |
| Qwen3_5_9B | validate_domain | +0.8 | +0.0 | +0.8 | -0.8 | +0.0 | +0.8 |
| Qwen3_5_9B | validate_problem | +6.5 | +2.0 | +0.0 | +2.0 | -0.5 | +5.0 |
| Qwen3_5_9B | validate_plan | -7.4 | -6.0 | -3.8 | -2.4 | -2.5 | -2.5 |
| Qwen3_5_9B | solve | -5.0 | -9.0 | -8.0 | -1.0 | +7.0 | -1.0 |
| Qwen3_5_9B | simulate | +1.0 | -7.0 | +2.0 | -1.0 | +0.0 | -1.0 |
| qwen3_6_35b | validate_domain | -1.7 | -2.5 | -0.8 | -1.7 | +2.5 | -4.2 |
| qwen3_6_35b | validate_problem | -1.0 | -1.5 | -2.0 | -2.5 | +0.0 | +0.5 |
| qwen3_6_35b | validate_plan | -0.7 | -0.5 | -0.6 | -0.7 | -1.0 | -0.6 |
| qwen3_6_35b | solve | -2.0 | -17.0 | -15.0 | +0.0 | +0.0 | -6.0 |
| qwen3_6_35b | simulate | -2.0 | -4.0 | -4.0 | -2.0 | -5.0 | -3.0 |
