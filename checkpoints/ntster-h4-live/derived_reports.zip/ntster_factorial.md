# nt-ster §4(b) — within-July factorial (attribution replication)

Interaction Δ_wt(ster−neut) − Δ_nt(ster−neut) · delivered surface · 90% intervals · GT gate `6af57125bde3`

> **Attribution-only.** §2.3(A) declares this comparison structurally budget-unmatchable (`chat_with_tools` re-grants the per-task decode budget every turn up to `MAX_TOOL_LOOPS = 10`; a no-tools trial gets one shared budget). It is not a capability measurement and no rate from it may be quoted as an effect size.

## Clause verdict: **DROP**

§5's PASS sentence DROPS the 'replicated attribution' clause, as pre-registered — it is not rewritten or weakened, it is removed.

| model | Δ_wt | Δ_nt | interaction [90% CI] | excludes 0 | May sign | replicated |
|---|---:|---:|---|---|---|---|
| Qwen/Qwen3.5-9B | +3.97 | +2.00 | +0.83 [-1.98, +3.64] | no | +9.76 | no |
| cyankiwi/Qwen3.6-35B-A3B-AWQ-4bit | +1.27 | -0.44 | -0.00 [-2.21, +2.21] | no | +0.46 | no |

## Qwen/Qwen3.5-9B

- nt leg: `slurm_vllm_Qwen3_5_9B_on_no-tools_ntster-h4` (complete: True)
- wt leg: `slurm_vllm_Qwen3_5_9B_on_tools_all_minimal_iss024d-e2e` (complete: True)
- 4,560 matched fixtures, 0 dropped

| interval | interaction [90% CI] | half-width |
|---|---|---:|
| domain | +1.97 [-0.09, +4.04] | 2.07pp |
| problem | +0.83 [-1.98, +3.64] | 2.81pp |
| governing | +0.83 [-1.98, +3.64] | 2.81pp |
| bootstrap_domain | +1.97 [+0.00, +3.82] | 1.91pp |

**Per task** (descriptive; §4(b) states the estimand per model, so no per-task cell carries clause authority).

| task | Δ_wt | Δ_nt | interaction [90% CI] |
|---|---:|---:|---|
| solve | -9.00 | +1.33 | -10.33 [-21.51, +0.84] |
| validate_domain | -1.11 | +10.28 | -11.39 [-18.91, -3.87] |
| validate_problem | +0.50 | +5.67 | -5.17 [-10.07, -0.26] |
| validate_plan | +7.40 | +0.07 | +7.33 [+3.92, +10.74] |
| simulate | -4.33 | +4.67 | -9.00 [-17.42, -0.58] |


## cyankiwi/Qwen3.6-35B-A3B-AWQ-4bit

- nt leg: `slurm_vllm_qwen3_6_35b_on_no-tools_ntster-h4` (complete: True)
- wt leg: `slurm_vllm_qwen3_6_35b_on_tools_all_minimal_iss024d-e2e` (complete: True)
- 4,560 matched fixtures, 0 dropped

| interval | interaction [90% CI] | half-width |
|---|---|---:|
| domain | +1.71 [+0.03, +3.39] | 1.68pp |
| problem | -0.00 [-2.21, +2.21] | 2.21pp |
| governing | -0.00 [-2.21, +2.21] | 2.21pp |
| bootstrap_domain | +1.71 [+0.22, +3.31] | 1.55pp |

**Per task** (descriptive; §4(b) states the estimand per model, so no per-task cell carries clause authority).

| task | Δ_wt | Δ_nt | interaction [90% CI] |
|---|---:|---:|---|
| solve | -3.33 | -7.67 | +4.33 [-6.48, +15.15] |
| validate_domain | -0.83 | -2.50 | +1.67 [-3.78, +7.11] |
| validate_problem | -0.33 | +1.17 | -1.50 [-3.48, +0.48] |
| validate_plan | +2.47 | -0.30 | +2.77 [+0.08, +5.46] |
| simulate | -0.33 | +4.67 | -5.00 [-12.09, +2.09] |

