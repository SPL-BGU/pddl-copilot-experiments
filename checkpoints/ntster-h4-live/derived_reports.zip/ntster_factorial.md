# nt-ster §4(b) — within-July factorial (attribution replication)

Interaction Δ_wt(ster−neut) − Δ_nt(ster−neut) · delivered surface · 90% intervals · GT gate `6af57125bde3`

> **Attribution-only.** §2.3(A) declares this comparison structurally budget-unmatchable (`chat_with_tools` re-grants the per-task decode budget every turn up to `MAX_TOOL_LOOPS = 10`; a no-tools trial gets one shared budget). It is not a capability measurement and no rate from it may be quoted as an effect size.

## Clause verdict: **DROP**

§5's PASS sentence DROPS the 'replicated attribution' clause, as pre-registered — it is not rewritten or weakened, it is removed.

| model | Δ_wt | Δ_nt | interaction [90% CI] | excludes 0 | May sign | replicated |
|---|---:|---:|---|---|---|---|
| Qwen/Qwen3.5-9B | +8.54 | +1.87 | +8.12 [+4.61, +11.63] | yes | +11.38 | **yes** |
| cyankiwi/Qwen3.6-35B-A3B-AWQ-4bit | +2.05 | -0.47 | +2.62 [+0.74, +4.50] | yes | -0.11 | no |

## Qwen/Qwen3.5-9B

- nt leg: `slurm_vllm_Qwen3_5_9B_on_no-tools_ntster-h4` (complete: True)
- wt leg: `slurm_vllm_Qwen3_5_9B_on_tools_all_minimal_iss024d-e2e` (complete: True)
- 3,765 matched fixtures, 788 dropped (unmatched or indeterminate on either leg, §2.3(C))

| interval | interaction [90% CI] | half-width |
|---|---|---:|
| domain | +8.12 [+4.61, +11.63] | 3.51pp |
| problem | +7.14 [+4.83, +9.46] | 2.31pp |
| governing | +8.12 [+4.61, +11.63] | 3.51pp |
| bootstrap_domain | +8.12 [+5.02, +11.42] | 3.20pp |

**Per task** (descriptive; §4(b) states the estimand per model, so no per-task cell carries clause authority).

| task | Δ_wt | Δ_nt | interaction [90% CI] |
|---|---:|---:|---|
| solve | +13.82 | +1.33 | +10.53 [-0.98, +22.03] |
| validate_domain | -1.15 | +10.28 | -12.17 [-19.91, -4.43] |
| validate_problem | +0.91 | +5.67 | -4.98 [-9.96, +0.00] |
| validate_plan | +12.31 | +0.07 | +15.01 [+9.01, +21.00] |
| simulate | -0.71 | +2.92 | -1.61 [-9.33, +6.11] |


## cyankiwi/Qwen3.6-35B-A3B-AWQ-4bit

- nt leg: `slurm_vllm_qwen3_6_35b_on_no-tools_ntster-h4` (complete: True)
- wt leg: `slurm_vllm_qwen3_6_35b_on_tools_all_minimal_iss024d-e2e` (complete: True)
- 4,417 matched fixtures, 143 dropped (unmatched or indeterminate on either leg, §2.3(C))

| interval | interaction [90% CI] | half-width |
|---|---|---:|
| domain | +2.62 [+0.74, +4.50] | 1.88pp |
| problem | +2.54 [+0.91, +4.16] | 1.62pp |
| governing | +2.62 [+0.74, +4.50] | 1.88pp |
| bootstrap_domain | +2.62 [+0.96, +4.44] | 1.74pp |

**Per task** (descriptive; §4(b) states the estimand per model, so no per-task cell carries clause authority).

| task | Δ_wt | Δ_nt | interaction [90% CI] |
|---|---:|---:|---|
| solve | +9.61 | -7.67 | +19.21 [+11.49, +26.94] |
| validate_domain | -0.83 | -2.50 | +1.67 [-3.78, +7.11] |
| validate_problem | -0.51 | +1.17 | -1.85 [-3.67, -0.04] |
| validate_plan | +2.47 | -0.30 | +2.78 [+0.11, +5.44] |
| simulate | +0.67 | +5.42 | -5.56 [-13.21, +2.09] |

