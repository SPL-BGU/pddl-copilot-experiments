# nt-ster H4 — F gate (§3.2)

Anchor arm only (v11/v12/v13); margin ±5pp; 90% intervals; surface = delivered.

F = max |Δ̂| over the three designed-null paraphrase pairs. A cell whose own F ≥ the margin is UNINFORMATIVE at that granularity and cannot contribute a FAIL.

## slurm_vllm_Qwen3_5_4B_off_no-tools_ntster-h4

- completeness: **COMPLETE**
  - complete: 9,120 rows, 1,520/variant, per-(task, variant) shape exact

| granularity | anchor rate | F | driving pair | verdict |
|---|---:|---:|---|---|
| pooled | 60.3% | 2.09pp | v12-v13 | usable |
| solve | 6.7% | 17.00pp | v11-v12 | UNINFORMATIVE (F ≥ margin) |
| validate_domain | 19.2% | 7.50pp | v11-v12 | UNINFORMATIVE (F ≥ margin) |
| validate_problem | 56.0% | 5.50pp | v12-v13 | UNINFORMATIVE (F ≥ margin) |
| validate_plan | 74.5% | 1.40pp | v11-v12 | usable |
| simulate | 17.1% | 5.56pp | v12-v13 | UNINFORMATIVE (F ≥ margin) |

## slurm_vllm_Qwen3_5_9B_off_no-tools_ntster-h4

- completeness: **COMPLETE**
  - complete: 9,120 rows, 1,520/variant, per-(task, variant) shape exact

| granularity | anchor rate | F | driving pair | verdict |
|---|---:|---:|---|---|
| pooled | 65.6% | 0.55pp | v11-v13 | usable |
| solve | 10.3% | 28.00pp | v11-v12 | UNINFORMATIVE (F ≥ margin) |
| validate_domain | 25.3% | 14.17pp | v11-v13 | UNINFORMATIVE (F ≥ margin) |
| validate_problem | 66.3% | 4.50pp | v12-v13 | usable |
| validate_plan | 79.8% | 1.40pp | v12-v13 | usable |
| simulate | 10.9% | 9.78pp | v11-v12 | UNINFORMATIVE (F ≥ margin) |

## slurm_vllm_Qwen3_5_9B_on_no-tools_ntster-h4

- completeness: **COMPLETE**
  - complete: 9,120 rows, 1,520/variant, per-(task, variant) shape exact

| granularity | anchor rate | F | driving pair | verdict |
|---|---:|---:|---|---|
| pooled | 69.7% | 1.67pp | v11-v12 | usable |
| solve | 26.7% | 16.00pp | v11-v12 | UNINFORMATIVE (F ≥ margin) |
| validate_domain | 43.6% | 6.67pp | v11-v13 | UNINFORMATIVE (F ≥ margin) |
| validate_problem | 63.8% | 6.50pp | v11-v13 | UNINFORMATIVE (F ≥ margin) |
| validate_plan | 81.4% | 1.60pp | v11-v12 | usable |
| simulate | 32.5% | 30.50pp | v11-v12 | UNINFORMATIVE (F ≥ margin) |

## slurm_vllm_gemma4_26b-a4b_off_no-tools_ntster-h4

- completeness: **COMPLETE**
  - complete: 9,120 rows, 1,520/variant, per-(task, variant) shape exact

| granularity | anchor rate | F | driving pair | verdict |
|---|---:|---:|---|---|
| pooled | 77.8% | 2.75pp | v11-v12 | usable |
| solve | 10.3% | 14.00pp | v11-v12 | UNINFORMATIVE (F ≥ margin) |
| validate_domain | 79.2% | 5.00pp | v11-v12 | UNINFORMATIVE (F ≥ margin) |
| validate_problem | 77.7% | 4.00pp | v11-v12 | usable |
| validate_plan | 88.3% | 2.50pp | v11-v13 | usable |
| simulate | 28.0% | 36.33pp | v11-v12 | UNINFORMATIVE (F ≥ margin) |

## slurm_vllm_qwen3_6_35b_off_no-tools_ntster-h4

- completeness: **COMPLETE**
  - complete: 9,120 rows, 1,520/variant, per-(task, variant) shape exact

| granularity | anchor rate | F | driving pair | verdict |
|---|---:|---:|---|---|
| pooled | 78.0% | 2.54pp | v12-v13 | usable |
| solve | 10.7% | 31.00pp | v12-v13 | UNINFORMATIVE (F ≥ margin) |
| validate_domain | 74.4% | 9.17pp | v12-v13 | UNINFORMATIVE (F ≥ margin) |
| validate_problem | 74.5% | 1.00pp | v11-v12 | usable |
| validate_plan | 90.5% | 0.60pp | v11-v13 | usable |
| simulate | 20.7% | 19.26pp | v11-v12 | UNINFORMATIVE (F ≥ margin) |

## slurm_vllm_qwen3_6_35b_on_no-tools_ntster-h4

- completeness: **COMPLETE**
  - complete: 9,120 rows, 1,520/variant, per-(task, variant) shape exact

| granularity | anchor rate | F | driving pair | verdict |
|---|---:|---:|---|---|
| pooled | 83.6% | 0.66pp | v11-v13 | usable |
| solve | 42.0% | 26.00pp | v11-v12 | UNINFORMATIVE (F ≥ margin) |
| validate_domain | 81.4% | 5.83pp | v11-v13 | UNINFORMATIVE (F ≥ margin) |
| validate_problem | 76.0% | 1.50pp | v11-v12 | usable |
| validate_plan | 92.6% | 1.20pp | v12-v13 | usable |
| simulate | 45.8% | 16.83pp | v12-v13 | UNINFORMATIVE (F ≥ margin) |

