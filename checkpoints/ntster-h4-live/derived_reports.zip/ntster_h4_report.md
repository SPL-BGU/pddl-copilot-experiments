# nt-ster H4 — confirmatory contrast

Margin ±5pp · 90% intervals · surface = delivered · bootstrap B=10,000 · GT gate `6af57125bde3`

Δ̂ = steered − anchor, on determinate rows (censored / ungradeable rows are excluded from every estimator and reported as bounds, §2.3(C)). The governing interval is the **wider** of the domain and problem-instance clusterings; each label carries its realized k.

## Paper-level branch: **PASS**

All units PASS.

## Verdict vector

| cell | anchor | steered | Δ̂ governing | F | verdict |
|---|---:|---:|---|---:|---|
| slurm_vllm_Qwen3_5_4B_off_no-tools_ntster-h4 | 60.3% | 58.8% | -1.07 [-2.32, +0.17] | 2.09 | **PASS** |
| slurm_vllm_Qwen3_5_9B_off_no-tools_ntster-h4 | 65.6% | 66.7% | +1.25 [+0.01, +2.50] | 0.55 | **PASS** |
| slurm_vllm_Qwen3_5_9B_on_no-tools_ntster-h4 | 69.7% | 71.7% | +1.87 [+0.69, +3.06] | 1.67 | **PASS** |
| slurm_vllm_gemma4_26b-a4b_off_no-tools_ntster-h4 | 77.8% | 78.3% | +0.53 [-0.29, +1.36] | 2.75 | **PASS** |
| slurm_vllm_qwen3_6_35b_off_no-tools_ntster-h4 | 78.0% | 78.0% | +0.16 [-0.89, +1.21] | 2.54 | **PASS** |
| slurm_vllm_qwen3_6_35b_on_no-tools_ntster-h4 | 83.6% | 83.1% | -0.46 [-1.33, +0.42] | 0.66 | **PASS** |

## slurm_vllm_Qwen3_5_4B_off_no-tools_ntster-h4

- complete: 9,120 rows, 1,520/variant, per-(task, variant) shape exact

**Pooled (primary).** anchor 60.32% (2697/4471), steered 58.75% (2648/4507), 4,466 matched pairs.

| interval | Δ̂ [90% CI] | half-width |
|---|---|---:|
| domain | -1.06 [-2.11, -0.02] | 1.04pp |
| problem | -1.07 [-2.32, +0.17] | 1.25pp |
| governing | -1.07 [-2.32, +0.17] | 1.25pp |
| bootstrap_domain | -1.06 [-2.06, -0.12] | 0.97pp |
| newcombe_unpaired | -1.57 [-3.27, +0.14] | 1.70pp |

- row-level pooled Δ: -1.57pp (cluster-mean vs row-level agree when clusters are balanced)
- label: **EQUIVALENT**
- MDE (|Δ| needed to FAIL): 6.25pp
- indeterminate rows (excluded, §2.3(C)): anchor 89, steered 53; extreme-imputation bounds on Δ̂: [-3.03, +0.09]pp over 4,560 pairs (94 with an indeterminate side)
- eligible-task mean (§3.3 point 2 companion): -1.10pp over 1 ELIGIBLE task cell(s) — consistent with the pooled read

**Per task.** Classification is assigned mechanically from the anchor and the realized precision, before the label is read.

| task | anchor | Δ̂ governing | half-width | F | class | label | MDE |
|---|---:|---|---:|---:|---|---|---:|
| solve | 6.7% | -1.67 [-4.32, +0.99] | 2.65 | 17.00 | UNINFORMATIVE | EQUIVALENT | 7.65 |
| validate_domain | 19.2% | +0.28 [-0.20, +0.76] | 0.48 | 7.50 | UNINFORMATIVE | EQUIVALENT | 5.48 |
| validate_problem | 56.0% | -1.00 [-3.81, +1.81] | 2.81 | 5.50 | UNINFORMATIVE | EQUIVALENT | 7.81 |
| validate_plan | 74.5% | -1.10 [-2.86, +0.66] | 1.76 | 1.40 | ELIGIBLE | EQUIVALENT | 6.76 |
| simulate | 17.1% | -2.43 [-5.33, +0.47] | 2.90 | 5.56 | UNINFORMATIVE | INDETERMINATE | 7.90 |

- `simulate` bounds (indeterminate excluded): Δ̂ ∈ [-31.67, +15.67]pp; censored anchor 89, steered 53

- ELIGIBLE family: validate_plan
- Intersection-union: the conjunctive equivalence claim needs no α correction and none is applied. Holm covers the ELIGIBLE family only, for the affirmative non-equivalence claim. Family membership is frozen by the pre-registered rule and is never re-picked after seeing Δ̂.

**Mechanism (secondary — never gates or revises the verdict).**

- label: none assigned

| component | anchor | steered | Δ̂ [90% CI] |
|---|---:|---:|---|
| TRUNCATED_LOSS | 3.78% | 3.95% | +0.20 [-0.30, +0.70] |
| CHANNEL_FORMAT | 4.43% | 4.17% | -0.24 [-0.64, +0.16] |
| CONTENT | 31.47% | 33.13% | +1.10 [-0.17, +2.38] |
| APPARATUS | 0.00% | 0.00% | +0.00 [+0.00, +0.00] |

- ΣΔ components +1.06pp vs −Δ̂ +1.06pp (domain clustering, the footing the components are computed on; residual +0.000pp)
- M1 directive echo, ARM DIFFERENCE: +0.48pp (anchor 0.11% → steered 0.59%)
- M2 budget: done_reason=length 6.5% → 5.7%; mean completion tokens 1663 → 1588; at-cap 5.5% → 4.8%
- censored at snapshot cap (reported separately, folded into neither side): anchor 1.95%, steered 1.16%

  > The four components partition Δ̂ exactly (ΣΔ = −Δ̂): this is an accounting split with CIs, not two independent measurements. Δtruncation must not be presented as corroborating ΔTRUNCATED-LOSS — they are the same rows.
  > M1 is an ARM DIFFERENCE, never an absolute: base rate in the roster neutral no-tools arms is 0/27,360, but that anchor is measured on 500-char snapshots and is a specificity floor. M1 is a lower bound on at-cap rows and is anti-correlated with displacement by construction, so a depressed M1 inside a displacement-dominated cell may not be read as 'no directive echo'.
  > No mechanism label: assigned only to cells whose H4 verdict is FAIL.

## slurm_vllm_Qwen3_5_9B_off_no-tools_ntster-h4

- complete: 9,120 rows, 1,520/variant, per-(task, variant) shape exact

**Pooled (primary).** anchor 65.58% (2938/4480), steered 66.71% (2994/4488), 4,469 matched pairs.

| interval | Δ̂ [90% CI] | half-width |
|---|---|---:|
| domain | +1.25 [+0.01, +2.50] | 1.25pp |
| problem | +1.25 [+0.11, +2.39] | 1.14pp |
| governing | +1.25 [+0.01, +2.50] | 1.25pp |
| bootstrap_domain | +1.25 [+0.09, +2.38] | 1.15pp |
| newcombe_unpaired | +1.13 [-0.51, +2.77] | 1.64pp |

- row-level pooled Δ: +1.13pp (cluster-mean vs row-level agree when clusters are balanced)
- label: **EQUIVALENT**
- MDE (|Δ| needed to FAIL): 6.25pp
- indeterminate rows (excluded, §2.3(C)): anchor 80, steered 72; extreme-imputation bounds on Δ̂: [-0.53, +2.81]pp over 4,560 pairs (91 with an indeterminate side)
- eligible-task mean (§3.3 point 2 companion): +0.98pp over 2 ELIGIBLE task cell(s) — consistent with the pooled read

**Per task.** Classification is assigned mechanically from the anchor and the realized precision, before the label is read.

| task | anchor | Δ̂ governing | half-width | F | class | label | MDE |
|---|---:|---|---:|---:|---|---|---:|
| solve | 10.3% | -1.67 [-4.89, +1.56] | 3.23 | 28.00 | UNINFORMATIVE | EQUIVALENT | 8.23 |
| validate_domain | 25.3% | +4.17 [-0.07, +8.40] | 4.23 | 14.17 | UNINFORMATIVE | INDETERMINATE | 9.23 |
| validate_problem | 66.3% | +1.33 [-1.72, +4.39] | 3.06 | 4.50 | ELIGIBLE | EQUIVALENT | 8.06 |
| validate_plan | 79.8% | +0.63 [-1.24, +2.50] | 1.87 | 1.40 | ELIGIBLE | EQUIVALENT | 6.87 |
| simulate | 10.9% | +6.95 [+2.71, +11.18] | 4.24 | 9.78 | UNINFORMATIVE | INDETERMINATE | 9.24 |

- `simulate` bounds (indeterminate excluded): Δ̂ ∈ [-20.33, +30.33]pp; censored anchor 80, steered 72

- ELIGIBLE family: validate_problem, validate_plan
- Intersection-union: the conjunctive equivalence claim needs no α correction and none is applied. Holm covers the ELIGIBLE family only, for the affirmative non-equivalence claim. Family membership is frozen by the pre-registered rule and is never re-picked after seeing Δ̂.

**Mechanism (secondary — never gates or revises the verdict).**

- label: none assigned

| component | anchor | steered | Δ̂ [90% CI] |
|---|---:|---:|---|
| TRUNCATED_LOSS | 3.95% | 3.43% | -0.52 [-1.33, +0.29] |
| CHANNEL_FORMAT | 4.84% | 5.59% | +0.77 [+0.44, +1.09] |
| CONTENT | 25.62% | 24.26% | -1.50 [-2.79, -0.20] |
| APPARATUS | 0.00% | 0.00% | +0.00 [+0.00, +0.00] |

- ΣΔ components -1.25pp vs −Δ̂ -1.25pp (domain clustering, the footing the components are computed on; residual -0.000pp)
- M1 directive echo, ARM DIFFERENCE: +0.37pp (anchor 0.26% → steered 0.64%)
- M2 budget: done_reason=length 6.4% → 5.8%; mean completion tokens 1871 → 1808; at-cap 6.3% → 5.3%
- censored at snapshot cap (reported separately, folded into neither side): anchor 1.75%, steered 1.58%

  > The four components partition Δ̂ exactly (ΣΔ = −Δ̂): this is an accounting split with CIs, not two independent measurements. Δtruncation must not be presented as corroborating ΔTRUNCATED-LOSS — they are the same rows.
  > M1 is an ARM DIFFERENCE, never an absolute: base rate in the roster neutral no-tools arms is 0/27,360, but that anchor is measured on 500-char snapshots and is a specificity floor. M1 is a lower bound on at-cap rows and is anti-correlated with displacement by construction, so a depressed M1 inside a displacement-dominated cell may not be read as 'no directive echo'.
  > No mechanism label: assigned only to cells whose H4 verdict is FAIL.

## slurm_vllm_Qwen3_5_9B_on_no-tools_ntster-h4

- complete: 9,120 rows, 1,520/variant, per-(task, variant) shape exact

**Pooled (primary).** anchor 69.71% (3143/4509), steered 71.68% (3227/4502), 4,500 matched pairs.

| interval | Δ̂ [90% CI] | half-width |
|---|---|---:|
| domain | +1.87 [+0.69, +3.06] | 1.18pp |
| problem | +1.87 [+0.95, +2.78] | 0.91pp |
| governing | +1.87 [+0.69, +3.06] | 1.18pp |
| bootstrap_domain | +1.87 [+0.78, +2.97] | 1.10pp |
| newcombe_unpaired | +1.97 [+0.40, +3.55] | 1.58pp |

- row-level pooled Δ: +1.97pp (cluster-mean vs row-level agree when clusters are balanced)
- label: **EQUIVALENT**
- MDE (|Δ| needed to FAIL): 6.18pp
- indeterminate rows (excluded, §2.3(C)): anchor 51, steered 58; extreme-imputation bounds on Δ̂: [+0.72, +3.11]pp over 4,560 pairs (60 with an indeterminate side)
- eligible-task mean (§3.3 point 2 companion): +0.07pp over 1 ELIGIBLE task cell(s) — consistent with the pooled read

**Per task.** Classification is assigned mechanically from the anchor and the realized precision, before the label is read.

| task | anchor | Δ̂ governing | half-width | F | class | label | MDE |
|---|---:|---|---:|---:|---|---|---:|
| solve | 26.7% | +1.33 [-4.31, +6.98] | 5.65 | 16.00 | UNINFORMATIVE | INDETERMINATE ⚠ | 10.65 |
| validate_domain | 43.6% | +10.28 [+3.30, +17.26] | 6.98 | 6.67 | UNINFORMATIVE | INDETERMINATE ⚠ | 11.98 |
| validate_problem | 63.8% | +5.67 [+1.76, +9.57] | 3.90 | 6.50 | UNINFORMATIVE | INDETERMINATE | 8.90 |
| validate_plan | 81.4% | +0.07 [-1.10, +1.23] | 1.17 | 1.60 | ELIGIBLE | EQUIVALENT | 6.17 |
| simulate | 32.5% | +3.83 [-3.73, +11.39] | 7.56 | 30.50 | UNINFORMATIVE | INDETERMINATE ⚠ | 12.56 |

- `simulate` bounds (indeterminate excluded): Δ̂ ∈ [-14.67, +21.67]pp; censored anchor 51, steered 58

- ELIGIBLE family: validate_plan
- Intersection-union: the conjunctive equivalence claim needs no α correction and none is applied. Holm covers the ELIGIBLE family only, for the affirmative non-equivalence claim. Family membership is frozen by the pre-registered rule and is never re-picked after seeing Δ̂.

**Mechanism (secondary — never gates or revises the verdict).**

- label: none assigned

| component | anchor | steered | Δ̂ [90% CI] |
|---|---:|---:|---|
| TRUNCATED_LOSS | 10.65% | 8.42% | -2.25 [-2.98, -1.52] |
| CHANNEL_FORMAT | 1.95% | 1.91% | -0.03 [-0.35, +0.30] |
| CONTENT | 17.70% | 17.99% | +0.41 [-0.38, +1.20] |
| APPARATUS | 0.00% | 0.00% | +0.00 [+0.00, +0.00] |

- ΣΔ components -1.87pp vs −Δ̂ -1.87pp (domain clustering, the footing the components are computed on; residual -0.000pp)
- M1 directive echo, ARM DIFFERENCE: +0.20pp (anchor 0.00% → steered 0.20%)
- M2 budget: done_reason=length 12.6% → 10.2%; mean completion tokens 7682 → 7081; at-cap 2.8% → 2.2%
- censored at snapshot cap (reported separately, folded into neither side): anchor 1.12%, steered 1.27%

  > The four components partition Δ̂ exactly (ΣΔ = −Δ̂): this is an accounting split with CIs, not two independent measurements. Δtruncation must not be presented as corroborating ΔTRUNCATED-LOSS — they are the same rows.
  > M1 is an ARM DIFFERENCE, never an absolute: base rate in the roster neutral no-tools arms is 0/27,360, but that anchor is measured on 500-char snapshots and is a specificity floor. M1 is a lower bound on at-cap rows and is anti-correlated with displacement by construction, so a depressed M1 inside a displacement-dominated cell may not be read as 'no directive echo'.
  > No mechanism label: assigned only to cells whose H4 verdict is FAIL.

## slurm_vllm_gemma4_26b-a4b_off_no-tools_ntster-h4

- complete: 9,120 rows, 1,520/variant, per-(task, variant) shape exact

**Pooled (primary).** anchor 77.83% (3496/4492), steered 78.33% (3520/4494), 4,491 matched pairs.

| interval | Δ̂ [90% CI] | half-width |
|---|---|---:|
| domain | +0.54 [-0.20, +1.28] | 0.74pp |
| problem | +0.53 [-0.29, +1.36] | 0.82pp |
| governing | +0.53 [-0.29, +1.36] | 0.82pp |
| bootstrap_domain | +0.54 [-0.17, +1.19] | 0.68pp |
| newcombe_unpaired | +0.50 [-0.94, +1.94] | 1.44pp |

- row-level pooled Δ: +0.50pp (cluster-mean vs row-level agree when clusters are balanced)
- label: **EQUIVALENT**
- MDE (|Δ| needed to FAIL): 5.82pp
- indeterminate rows (excluded, §2.3(C)): anchor 68, steered 66; extreme-imputation bounds on Δ̂: [-0.96, +1.97]pp over 4,560 pairs (69 with an indeterminate side)
- eligible-task mean (§3.3 point 2 companion): +0.07pp over 2 ELIGIBLE task cell(s) — consistent with the pooled read

**Per task.** Classification is assigned mechanically from the anchor and the realized precision, before the label is read.

| task | anchor | Δ̂ governing | half-width | F | class | label | MDE |
|---|---:|---|---:|---:|---|---|---:|
| solve | 10.3% | -4.00 [-7.68, -0.32] | 3.68 | 14.00 | UNINFORMATIVE | INDETERMINATE | 8.68 |
| validate_domain | 79.2% | -1.39 [-4.86, +2.09] | 3.48 | 5.00 | UNINFORMATIVE | EQUIVALENT | 8.48 |
| validate_problem | 77.7% | -0.50 [-2.88, +1.88] | 2.38 | 4.00 | ELIGIBLE | EQUIVALENT | 7.38 |
| validate_plan | 88.3% | +0.63 [-0.46, +1.73] | 1.10 | 2.50 | ELIGIBLE | EQUIVALENT | 6.10 |
| simulate | 28.0% | +9.00 [+4.68, +13.32] | 4.32 | 36.33 | UNINFORMATIVE | INDETERMINATE | 9.32 |

- `simulate` bounds (indeterminate excluded): Δ̂ ∈ [-14.33, +30.33]pp; censored anchor 68, steered 66

- ELIGIBLE family: validate_problem, validate_plan
- Intersection-union: the conjunctive equivalence claim needs no α correction and none is applied. Holm covers the ELIGIBLE family only, for the affirmative non-equivalence claim. Family membership is frozen by the pre-registered rule and is never re-picked after seeing Δ̂.

**Mechanism (secondary — never gates or revises the verdict).**

- label: none assigned

| component | anchor | steered | Δ̂ [90% CI] |
|---|---:|---:|---|
| TRUNCATED_LOSS | 1.58% | 1.31% | -0.28 [-0.69, +0.14] |
| CHANNEL_FORMAT | 6.52% | 6.83% | +0.31 [-0.26, +0.87] |
| CONTENT | 14.07% | 13.53% | -0.57 [-1.36, +0.22] |
| APPARATUS | 0.00% | 0.00% | +0.00 [+0.00, +0.00] |

- ΣΔ components -0.54pp vs −Δ̂ -0.54pp (domain clustering, the footing the components are computed on; residual -0.000pp)
- M1 directive echo, ARM DIFFERENCE: +0.02pp (anchor 0.00% → steered 0.02%)
- M2 budget: done_reason=length 3.3% → 3.1%; mean completion tokens 1275 → 1303; at-cap 3.0% → 2.7%
- censored at snapshot cap (reported separately, folded into neither side): anchor 1.49%, steered 1.45%

  > The four components partition Δ̂ exactly (ΣΔ = −Δ̂): this is an accounting split with CIs, not two independent measurements. Δtruncation must not be presented as corroborating ΔTRUNCATED-LOSS — they are the same rows.
  > M1 is an ARM DIFFERENCE, never an absolute: base rate in the roster neutral no-tools arms is 0/27,360, but that anchor is measured on 500-char snapshots and is a specificity floor. M1 is a lower bound on at-cap rows and is anti-correlated with displacement by construction, so a depressed M1 inside a displacement-dominated cell may not be read as 'no directive echo'.
  > No mechanism label: assigned only to cells whose H4 verdict is FAIL.

## slurm_vllm_qwen3_6_35b_off_no-tools_ntster-h4

- complete: 9,120 rows, 1,520/variant, per-(task, variant) shape exact

**Pooled (primary).** anchor 78.05% (3513/4501), steered 77.98% (3520/4514), 4,494 matched pairs.

| interval | Δ̂ [90% CI] | half-width |
|---|---|---:|
| domain | +0.16 [-0.89, +1.21] | 1.05pp |
| problem | +0.16 [-0.68, +0.99] | 0.83pp |
| governing | +0.16 [-0.89, +1.21] | 1.05pp |
| bootstrap_domain | +0.16 [-0.81, +1.12] | 0.96pp |
| newcombe_unpaired | -0.07 [-1.50, +1.37] | 1.43pp |

- row-level pooled Δ: -0.07pp (cluster-mean vs row-level agree when clusters are balanced)
- label: **EQUIVALENT**
- MDE (|Δ| needed to FAIL): 6.05pp
- indeterminate rows (excluded, §2.3(C)): anchor 59, steered 46; extreme-imputation bounds on Δ̂: [-1.14, +1.16]pp over 4,560 pairs (66 with an indeterminate side)
- eligible-task mean (§3.3 point 2 companion): +0.83pp over 1 ELIGIBLE task cell(s) — consistent with the pooled read

**Per task.** Classification is assigned mechanically from the anchor and the realized precision, before the label is read.

| task | anchor | Δ̂ governing | half-width | F | class | label | MDE |
|---|---:|---|---:|---:|---|---|---:|
| solve | 10.7% | -1.33 [-5.13, +2.46] | 3.80 | 31.00 | UNINFORMATIVE | INDETERMINATE | 8.80 |
| validate_domain | 74.4% | +1.67 [-2.14, +5.47] | 3.80 | 9.17 | UNINFORMATIVE | INDETERMINATE | 8.80 |
| validate_problem | 74.5% | +0.83 [-1.36, +3.02] | 2.19 | 1.00 | ELIGIBLE | EQUIVALENT | 7.19 |
| validate_plan | 90.5% | -0.33 [-1.61, +0.94] | 1.27 | 0.60 | UNINFORMATIVE | EQUIVALENT | 6.27 |
| simulate | 20.7% | +3.36 [-1.01, +7.73] | 4.37 | 19.26 | UNINFORMATIVE | INDETERMINATE | 9.37 |

- `simulate` bounds (indeterminate excluded): Δ̂ ∈ [-16.33, +18.67]pp; censored anchor 59, steered 46

- ELIGIBLE family: validate_problem
- Intersection-union: the conjunctive equivalence claim needs no α correction and none is applied. Holm covers the ELIGIBLE family only, for the affirmative non-equivalence claim. Family membership is frozen by the pre-registered rule and is never re-picked after seeing Δ̂.

**Mechanism (secondary — never gates or revises the verdict).**

- label: none assigned

| component | anchor | steered | Δ̂ [90% CI] |
|---|---:|---:|---|
| TRUNCATED_LOSS | 1.80% | 1.53% | -0.28 [-0.90, +0.35] |
| CHANNEL_FORMAT | 6.64% | 6.05% | -0.53 [-1.07, +0.02] |
| CONTENT | 13.51% | 14.44% | +0.65 [-0.25, +1.54] |
| APPARATUS | 0.00% | 0.00% | +0.00 [+0.00, +0.00] |

- ΣΔ components -0.16pp vs −Δ̂ -0.16pp (domain clustering, the footing the components are computed on; residual +0.000pp)
- M1 directive echo, ARM DIFFERENCE: +0.79pp (anchor 0.02% → steered 0.81%)
- M2 budget: done_reason=length 3.2% → 3.0%; mean completion tokens 1950 → 1977; at-cap 4.0% → 3.6%
- censored at snapshot cap (reported separately, folded into neither side): anchor 1.29%, steered 1.01%

  > The four components partition Δ̂ exactly (ΣΔ = −Δ̂): this is an accounting split with CIs, not two independent measurements. Δtruncation must not be presented as corroborating ΔTRUNCATED-LOSS — they are the same rows.
  > M1 is an ARM DIFFERENCE, never an absolute: base rate in the roster neutral no-tools arms is 0/27,360, but that anchor is measured on 500-char snapshots and is a specificity floor. M1 is a lower bound on at-cap rows and is anti-correlated with displacement by construction, so a depressed M1 inside a displacement-dominated cell may not be read as 'no directive echo'.
  > No mechanism label: assigned only to cells whose H4 verdict is FAIL.

## slurm_vllm_qwen3_6_35b_on_no-tools_ntster-h4

- complete: 9,120 rows, 1,520/variant, per-(task, variant) shape exact

**Pooled (primary).** anchor 83.57% (3768/4509), steered 83.11% (3745/4506), 4,500 matched pairs.

| interval | Δ̂ [90% CI] | half-width |
|---|---|---:|
| domain | -0.46 [-1.33, +0.42] | 0.87pp |
| problem | -0.47 [-1.20, +0.26] | 0.73pp |
| governing | -0.46 [-1.33, +0.42] | 0.87pp |
| bootstrap_domain | -0.46 [-1.30, +0.32] | 0.81pp |
| newcombe_unpaired | -0.45 [-1.75, +0.84] | 1.29pp |

- row-level pooled Δ: -0.45pp (cluster-mean vs row-level agree when clusters are balanced)
- label: **EQUIVALENT**
- MDE (|Δ| needed to FAIL): 5.87pp
- indeterminate rows (excluded, §2.3(C)): anchor 51, steered 54; extreme-imputation bounds on Δ̂: [-1.62, +0.68]pp over 4,560 pairs (60 with an indeterminate side)
- eligible-task mean (§3.3 point 2 companion): +1.17pp over 1 ELIGIBLE task cell(s) — consistent with the pooled read

**Per task.** Classification is assigned mechanically from the anchor and the realized precision, before the label is read.

| task | anchor | Δ̂ governing | half-width | F | class | label | MDE |
|---|---:|---|---:|---:|---|---|---:|
| solve | 42.0% | -7.67 [-14.11, -1.23] | 6.44 | 26.00 | UNINFORMATIVE | INDETERMINATE ⚠ | 11.44 |
| validate_domain | 81.4% | -2.50 [-7.50, +2.50] | 5.00 | 5.83 | UNINFORMATIVE | INDETERMINATE ⚠ | 10.00 |
| validate_problem | 76.0% | +1.17 [-0.36, +2.70] | 1.53 | 1.50 | ELIGIBLE | EQUIVALENT | 6.53 |
| validate_plan | 92.6% | -0.30 [-1.10, +0.50] | 0.80 | 1.20 | UNINFORMATIVE | EQUIVALENT | 5.80 |
| simulate | 45.8% | +6.32 [-0.35, +12.98] | 6.66 | 16.83 | UNINFORMATIVE | INDETERMINATE ⚠ | 11.66 |

- `simulate` bounds (indeterminate excluded): Δ̂ ∈ [-13.33, +21.67]pp; censored anchor 51, steered 54

- ELIGIBLE family: validate_problem
- Intersection-union: the conjunctive equivalence claim needs no α correction and none is applied. Holm covers the ELIGIBLE family only, for the affirmative non-equivalence claim. Family membership is frozen by the pre-registered rule and is never re-picked after seeing Δ̂.

**Mechanism (secondary — never gates or revises the verdict).**

- label: none assigned

| component | anchor | steered | Δ̂ [90% CI] |
|---|---:|---:|---|
| TRUNCATED_LOSS | 3.30% | 3.71% | +0.38 [-0.30, +1.07] |
| CHANNEL_FORMAT | 2.08% | 1.75% | -0.31 [-0.72, +0.11] |
| CONTENT | 11.04% | 11.43% | +0.38 [-0.45, +1.22] |
| APPARATUS | 0.00% | 0.00% | +0.00 [+0.00, +0.00] |

- ΣΔ components +0.46pp vs −Δ̂ +0.46pp (domain clustering, the footing the components are computed on; residual +0.000pp)
- M1 directive echo, ARM DIFFERENCE: +0.00pp (anchor 0.00% → steered 0.00%)
- M2 budget: done_reason=length 4.9% → 5.3%; mean completion tokens 4157 → 4063; at-cap 1.1% → 1.2%
- censored at snapshot cap (reported separately, folded into neither side): anchor 1.12%, steered 1.18%

  > The four components partition Δ̂ exactly (ΣΔ = −Δ̂): this is an accounting split with CIs, not two independent measurements. Δtruncation must not be presented as corroborating ΔTRUNCATED-LOSS — they are the same rows.
  > M1 is an ARM DIFFERENCE, never an absolute: base rate in the roster neutral no-tools arms is 0/27,360, but that anchor is measured on 500-char snapshots and is a specificity floor. M1 is a lower bound on at-cap rows and is anti-correlated with displacement by construction, so a depressed M1 inside a displacement-dominated cell may not be read as 'no directive echo'.
  > No mechanism label: assigned only to cells whose H4 verdict is FAIL.

---

**Control conservatism (§3.5).** Under `with_tools=False` the system prompt is always `WITHOUT_TOOLS_SYSTEM_BY_TASK[task]` regardless of variant, which states that validation tools are not available, while the steered v14-16 user text tells the model to use a named tool. The control therefore removes both the tool and its stated availability, which **biases H4 toward PASS** — a PASS is weaker evidence than an unqualified reading would suggest.

**Serving nondeterminism** at T=0 is unbounded by our corpora: decoding is greedy and unseeded, and no prompt was ever measured twice under one apparatus. Registered as a stated limitation, not a number.

