# nt-ster H4 — confirmatory contrast

Margin ±5pp · 90% intervals · surface = delivered · bootstrap B=10,000 · GT gate `6af57125bde3`

Δ̂ = steered − anchor. The governing interval is the **wider** of the domain (k=20) and problem-instance (k=100) clusterings.

## Paper-level branch: **PASS**

All units PASS.

## Verdict vector

| cell | anchor | steered | Δ̂ governing | F | verdict |
|---|---:|---:|---|---:|---|
| slurm_vllm_Qwen3_5_4B_off_no-tools_ntster-h4 | 61.1% | 59.2% | -3.03 [-4.83, -1.23] | 1.51 | **PASS** |
| slurm_vllm_Qwen3_5_9B_off_no-tools_ntster-h4 | 66.2% | 67.2% | -0.18 [-1.89, +1.52] | 1.12 | **PASS** |
| slurm_vllm_Qwen3_5_9B_on_no-tools_ntster-h4 | 70.0% | 72.0% | +1.83 [-0.28, +3.94] | 2.17 | **PASS** |
| slurm_vllm_gemma4_26b-a4b_off_no-tools_ntster-h4 | 78.2% | 78.6% | +0.52 [-0.95, +1.99] | 2.76 | **PASS** |
| slurm_vllm_qwen3_6_35b_off_no-tools_ntster-h4 | 78.3% | 78.2% | +1.34 [-0.40, +3.08] | 2.24 | **PASS** |
| slurm_vllm_qwen3_6_35b_on_no-tools_ntster-h4 | 83.8% | 83.3% | +0.49 [-1.37, +2.35] | 0.86 | **PASS** |

## slurm_vllm_Qwen3_5_4B_off_no-tools_ntster-h4

- complete: 9,120 rows, 1,520/variant, per-(task, variant) shape exact

**Pooled (primary).** anchor 61.10% (2786/4560), steered 59.23% (2701/4560), 4,560 matched pairs.

| interval | Δ̂ [90% CI] | half-width |
|---|---|---:|
| domain | -1.86 [-2.98, -0.75] | 1.11pp |
| problem | -3.03 [-4.83, -1.23] | 1.80pp |
| governing | -3.03 [-4.83, -1.23] | 1.80pp |
| bootstrap_domain | -1.86 [-2.94, -0.86] | 1.04pp |
| newcombe_unpaired | -1.86 [-3.55, -0.18] | 1.69pp |

- row-level pooled Δ: -1.86pp (cluster-mean vs row-level agree when clusters are balanced)
- label: **EQUIVALENT**
- MDE (|Δ| needed to FAIL): 6.80pp

**Per task.** Classification is assigned mechanically from the anchor and the realized precision, before the label is read.

| task | anchor | Δ̂ governing | half-width | F | class | label | MDE |
|---|---:|---|---:|---:|---|---|---:|
| solve | 6.7% | -1.67 [-4.32, +0.99] | 2.65 | 17.00 | UNINFORMATIVE | EQUIVALENT | 7.65 |
| validate_domain | 19.2% | +0.28 [-0.20, +0.76] | 0.48 | 7.50 | UNINFORMATIVE | EQUIVALENT | 5.48 |
| validate_problem | 56.0% | -1.00 [-3.81, +1.81] | 2.81 | 5.50 | UNINFORMATIVE | EQUIVALENT | 7.81 |
| validate_plan | 74.5% | -1.10 [-2.86, +0.66] | 1.76 | 1.40 | ELIGIBLE | EQUIVALENT | 6.76 |
| simulate | 41.7% | -14.00 [-19.97, -8.03] | 5.97 | 12.00 | UNINFORMATIVE | NOT-EQUIVALENT ⚠ | 10.97 |


- ELIGIBLE family: validate_plan
- Intersection-union: the conjunctive equivalence claim needs no α correction and none is applied. Holm covers the ELIGIBLE family only, for the affirmative non-equivalence claim. Family membership is frozen by the pre-registered rule and is never re-picked after seeing Δ̂.

**Mechanism (secondary — never gates or revises the verdict).**

- label: VOID

| component | anchor | steered | Δ̂ [90% CI] |
|---|---:|---:|---|
| TRUNCATED_LOSS | 0.00% | 0.00% | +0.00 [+0.00, +0.00] |
| CHANNEL_FORMAT | 0.68% | 0.53% | -0.15 [-0.37, +0.06] |
| CONTENT | 3.16% | 4.23% | +1.07 [+0.65, +1.50] |
| APPARATUS | 35.07% | 36.01% | +0.94 [-0.08, +1.97] |

- ΣΔ components +1.86pp vs −Δ̂ +1.86pp (domain clustering, the footing the components are computed on; residual +0.000pp)
- M1 directive echo, ARM DIFFERENCE: +0.00pp (anchor 0.00% → steered 0.00%)
- M2 budget: done_reason=length 6.5% → 5.7%; mean completion tokens nan → nan; at-cap 0.0% → 0.0%
- censored at snapshot cap (reported separately, folded into neither side): anchor 1.95%, steered 1.16%

  > The four components partition Δ̂ exactly (ΣΔ = −Δ̂): this is an accounting split with CIs, not two independent measurements. Δtruncation must not be presented as corroborating ΔTRUNCATED-LOSS — they are the same rows.
  > APPARATUS share 35.07% in the anchor arm exceeds 1% — this cell's mechanism read is VOID.
  > APPARATUS share 36.01% in the steered arm exceeds 1% — this cell's mechanism read is VOID.
  > M1 is an ARM DIFFERENCE, never an absolute: base rate in the roster neutral no-tools arms is 0/27,360, but that anchor is measured on 500-char snapshots and is a specificity floor. M1 is a lower bound on at-cap rows and is anti-correlated with displacement by construction, so a depressed M1 inside a displacement-dominated cell may not be read as 'no directive echo'.

## slurm_vllm_Qwen3_5_9B_off_no-tools_ntster-h4

- complete: 9,120 rows, 1,520/variant, per-(task, variant) shape exact

**Pooled (primary).** anchor 66.18% (3018/4560), steered 67.24% (3066/4560), 4,560 matched pairs.

| interval | Δ̂ [90% CI] | half-width |
|---|---|---:|
| domain | +1.05 [-0.13, +2.24] | 1.18pp |
| problem | -0.18 [-1.89, +1.52] | 1.70pp |
| governing | -0.18 [-1.89, +1.52] | 1.70pp |
| bootstrap_domain | +1.05 [-0.07, +2.11] | 1.09pp |
| newcombe_unpaired | +1.05 [-0.57, +2.68] | 1.62pp |

- row-level pooled Δ: +1.05pp (cluster-mean vs row-level agree when clusters are balanced)
- label: **EQUIVALENT**
- MDE (|Δ| needed to FAIL): 6.70pp

**Per task.** Classification is assigned mechanically from the anchor and the realized precision, before the label is read.

| task | anchor | Δ̂ governing | half-width | F | class | label | MDE |
|---|---:|---|---:|---:|---|---|---:|
| solve | 10.3% | -1.67 [-4.89, +1.56] | 3.23 | 28.00 | UNINFORMATIVE | EQUIVALENT | 8.23 |
| validate_domain | 25.3% | +4.17 [-0.07, +8.40] | 4.23 | 14.17 | UNINFORMATIVE | INDETERMINATE | 9.23 |
| validate_problem | 66.3% | +1.33 [-1.72, +4.39] | 3.06 | 4.50 | ELIGIBLE | EQUIVALENT | 8.06 |
| validate_plan | 79.8% | +0.63 [-1.24, +2.50] | 1.87 | 1.40 | ELIGIBLE | EQUIVALENT | 6.87 |
| simulate | 34.7% | +3.67 [-2.56, +9.90] | 6.23 | 21.00 | UNINFORMATIVE | INDETERMINATE ⚠ | 11.23 |


- ELIGIBLE family: validate_problem, validate_plan
- Intersection-union: the conjunctive equivalence claim needs no α correction and none is applied. Holm covers the ELIGIBLE family only, for the affirmative non-equivalence claim. Family membership is frozen by the pre-registered rule and is never re-picked after seeing Δ̂.

**Mechanism (secondary — never gates or revises the verdict).**

- label: VOID

| component | anchor | steered | Δ̂ [90% CI] |
|---|---:|---:|---|
| TRUNCATED_LOSS | 0.00% | 0.00% | +0.00 [+0.00, +0.00] |
| CHANNEL_FORMAT | 0.81% | 0.75% | -0.07 [-0.25, +0.12] |
| CONTENT | 3.49% | 3.31% | -0.18 [-0.62, +0.27] |
| APPARATUS | 29.52% | 28.71% | -0.81 [-2.07, +0.45] |

- ΣΔ components -1.05pp vs −Δ̂ -1.05pp (domain clustering, the footing the components are computed on; residual -0.000pp)
- M1 directive echo, ARM DIFFERENCE: +0.00pp (anchor 0.00% → steered 0.00%)
- M2 budget: done_reason=length 6.4% → 5.8%; mean completion tokens nan → nan; at-cap 0.0% → 0.0%
- censored at snapshot cap (reported separately, folded into neither side): anchor 1.75%, steered 1.58%

  > The four components partition Δ̂ exactly (ΣΔ = −Δ̂): this is an accounting split with CIs, not two independent measurements. Δtruncation must not be presented as corroborating ΔTRUNCATED-LOSS — they are the same rows.
  > APPARATUS share 29.52% in the anchor arm exceeds 1% — this cell's mechanism read is VOID.
  > APPARATUS share 28.71% in the steered arm exceeds 1% — this cell's mechanism read is VOID.
  > M1 is an ARM DIFFERENCE, never an absolute: base rate in the roster neutral no-tools arms is 0/27,360, but that anchor is measured on 500-char snapshots and is a specificity floor. M1 is a lower bound on at-cap rows and is anti-correlated with displacement by construction, so a depressed M1 inside a displacement-dominated cell may not be read as 'no directive echo'.

## slurm_vllm_Qwen3_5_9B_on_no-tools_ntster-h4

- complete: 9,120 rows, 1,520/variant, per-(task, variant) shape exact

**Pooled (primary).** anchor 70.04% (3194/4560), steered 72.04% (3285/4560), 4,560 matched pairs.

| interval | Δ̂ [90% CI] | half-width |
|---|---|---:|
| domain | +2.00 [+0.81, +3.19] | 1.19pp |
| problem | +1.83 [-0.28, +3.94] | 2.11pp |
| governing | +1.83 [-0.28, +3.94] | 2.11pp |
| bootstrap_domain | +2.00 [+0.90, +3.09] | 1.10pp |
| newcombe_unpaired | +2.00 [+0.43, +3.56] | 1.56pp |

- row-level pooled Δ: +2.00pp (cluster-mean vs row-level agree when clusters are balanced)
- label: **EQUIVALENT**
- MDE (|Δ| needed to FAIL): 7.11pp

**Per task.** Classification is assigned mechanically from the anchor and the realized precision, before the label is read.

| task | anchor | Δ̂ governing | half-width | F | class | label | MDE |
|---|---:|---|---:|---:|---|---|---:|
| solve | 26.7% | +1.33 [-4.31, +6.98] | 5.65 | 16.00 | UNINFORMATIVE | INDETERMINATE ⚠ | 10.65 |
| validate_domain | 43.6% | +10.28 [+3.30, +17.26] | 6.98 | 6.67 | UNINFORMATIVE | INDETERMINATE ⚠ | 11.98 |
| validate_problem | 63.8% | +5.67 [+1.76, +9.57] | 3.90 | 6.50 | UNINFORMATIVE | INDETERMINATE | 8.90 |
| validate_plan | 81.4% | +0.07 [-1.10, +1.23] | 1.17 | 1.60 | ELIGIBLE | EQUIVALENT | 6.17 |
| simulate | 44.0% | +4.67 [-2.18, +11.52] | 6.85 | 32.00 | UNINFORMATIVE | INDETERMINATE ⚠ | 11.85 |


- ELIGIBLE family: validate_plan
- Intersection-union: the conjunctive equivalence claim needs no α correction and none is applied. Holm covers the ELIGIBLE family only, for the affirmative non-equivalence claim. Family membership is frozen by the pre-registered rule and is never re-picked after seeing Δ̂.

**Mechanism (secondary — never gates or revises the verdict).**

- label: VOID

| component | anchor | steered | Δ̂ [90% CI] |
|---|---:|---:|---|
| TRUNCATED_LOSS | 0.00% | 0.00% | +0.00 [+0.00, +0.00] |
| CHANNEL_FORMAT | 1.21% | 0.46% | -0.75 [-0.97, -0.52] |
| CONTENT | 1.91% | 2.57% | +0.66 [+0.25, +1.06] |
| APPARATUS | 26.84% | 24.93% | -1.91 [-3.08, -0.74] |

- ΣΔ components -2.00pp vs −Δ̂ -2.00pp (domain clustering, the footing the components are computed on; residual +0.000pp)
- M1 directive echo, ARM DIFFERENCE: +0.00pp (anchor 0.00% → steered 0.00%)
- M2 budget: done_reason=length 12.6% → 10.2%; mean completion tokens nan → nan; at-cap 0.0% → 0.0%
- censored at snapshot cap (reported separately, folded into neither side): anchor 1.12%, steered 1.27%

  > The four components partition Δ̂ exactly (ΣΔ = −Δ̂): this is an accounting split with CIs, not two independent measurements. Δtruncation must not be presented as corroborating ΔTRUNCATED-LOSS — they are the same rows.
  > APPARATUS share 26.84% in the anchor arm exceeds 1% — this cell's mechanism read is VOID.
  > APPARATUS share 24.93% in the steered arm exceeds 1% — this cell's mechanism read is VOID.
  > M1 is an ARM DIFFERENCE, never an absolute: base rate in the roster neutral no-tools arms is 0/27,360, but that anchor is measured on 500-char snapshots and is a specificity floor. M1 is a lower bound on at-cap rows and is anti-correlated with displacement by construction, so a depressed M1 inside a displacement-dominated cell may not be read as 'no directive echo'.

## slurm_vllm_gemma4_26b-a4b_off_no-tools_ntster-h4

- complete: 9,120 rows, 1,520/variant, per-(task, variant) shape exact

**Pooled (primary).** anchor 78.16% (3564/4560), steered 78.64% (3586/4560), 4,560 matched pairs.

| interval | Δ̂ [90% CI] | half-width |
|---|---|---:|
| domain | +0.48 [-0.23, +1.20] | 0.71pp |
| problem | +0.52 [-0.95, +1.99] | 1.47pp |
| governing | +0.52 [-0.95, +1.99] | 1.47pp |
| bootstrap_domain | +0.48 [-0.20, +1.10] | 0.65pp |
| newcombe_unpaired | +0.48 [-0.94, +1.90] | 1.42pp |

- row-level pooled Δ: +0.48pp (cluster-mean vs row-level agree when clusters are balanced)
- label: **EQUIVALENT**
- MDE (|Δ| needed to FAIL): 6.47pp

**Per task.** Classification is assigned mechanically from the anchor and the realized precision, before the label is read.

| task | anchor | Δ̂ governing | half-width | F | class | label | MDE |
|---|---:|---|---:|---:|---|---|---:|
| solve | 10.3% | -4.00 [-7.68, -0.32] | 3.68 | 14.00 | UNINFORMATIVE | INDETERMINATE | 8.68 |
| validate_domain | 79.2% | -1.39 [-4.86, +2.09] | 3.48 | 5.00 | UNINFORMATIVE | EQUIVALENT | 8.48 |
| validate_problem | 77.7% | -0.50 [-2.88, +1.88] | 2.38 | 4.00 | ELIGIBLE | EQUIVALENT | 7.38 |
| validate_plan | 88.3% | +0.63 [-0.46, +1.73] | 1.10 | 2.50 | ELIGIBLE | EQUIVALENT | 6.10 |
| simulate | 44.3% | +7.67 [+3.22, +12.11] | 4.45 | 34.00 | UNINFORMATIVE | INDETERMINATE | 9.45 |


- ELIGIBLE family: validate_problem, validate_plan
- Intersection-union: the conjunctive equivalence claim needs no α correction and none is applied. Holm covers the ELIGIBLE family only, for the affirmative non-equivalence claim. Family membership is frozen by the pre-registered rule and is never re-picked after seeing Δ̂.

**Mechanism (secondary — never gates or revises the verdict).**

- label: VOID

| component | anchor | steered | Δ̂ [90% CI] |
|---|---:|---:|---|
| TRUNCATED_LOSS | 0.00% | 0.00% | +0.00 [+0.00, +0.00] |
| CHANNEL_FORMAT | 2.15% | 1.71% | -0.44 [-0.67, -0.21] |
| CONTENT | 1.51% | 1.45% | -0.07 [-0.31, +0.18] |
| APPARATUS | 18.18% | 18.20% | +0.02 [-0.71, +0.75] |

- ΣΔ components -0.48pp vs −Δ̂ -0.48pp (domain clustering, the footing the components are computed on; residual +0.000pp)
- M1 directive echo, ARM DIFFERENCE: +0.00pp (anchor 0.00% → steered 0.00%)
- M2 budget: done_reason=length 3.3% → 3.1%; mean completion tokens nan → nan; at-cap 0.0% → 0.0%
- censored at snapshot cap (reported separately, folded into neither side): anchor 1.49%, steered 1.45%

  > The four components partition Δ̂ exactly (ΣΔ = −Δ̂): this is an accounting split with CIs, not two independent measurements. Δtruncation must not be presented as corroborating ΔTRUNCATED-LOSS — they are the same rows.
  > APPARATUS share 18.18% in the anchor arm exceeds 1% — this cell's mechanism read is VOID.
  > APPARATUS share 18.20% in the steered arm exceeds 1% — this cell's mechanism read is VOID.
  > M1 is an ARM DIFFERENCE, never an absolute: base rate in the roster neutral no-tools arms is 0/27,360, but that anchor is measured on 500-char snapshots and is a specificity floor. M1 is a lower bound on at-cap rows and is anti-correlated with displacement by construction, so a depressed M1 inside a displacement-dominated cell may not be read as 'no directive echo'.

## slurm_vllm_qwen3_6_35b_off_no-tools_ntster-h4

- complete: 9,120 rows, 1,520/variant, per-(task, variant) shape exact

**Pooled (primary).** anchor 78.33% (3572/4560), steered 78.20% (3566/4560), 4,560 matched pairs.

| interval | Δ̂ [90% CI] | half-width |
|---|---|---:|
| domain | -0.13 [-1.16, +0.89] | 1.02pp |
| problem | +1.34 [-0.40, +3.08] | 1.74pp |
| governing | +1.34 [-0.40, +3.08] | 1.74pp |
| bootstrap_domain | -0.13 [-1.07, +0.81] | 0.94pp |
| newcombe_unpaired | -0.13 [-1.55, +1.29] | 1.42pp |

- row-level pooled Δ: -0.13pp (cluster-mean vs row-level agree when clusters are balanced)
- label: **EQUIVALENT**
- MDE (|Δ| needed to FAIL): 6.74pp

**Per task.** Classification is assigned mechanically from the anchor and the realized precision, before the label is read.

| task | anchor | Δ̂ governing | half-width | F | class | label | MDE |
|---|---:|---|---:|---:|---|---|---:|
| solve | 10.7% | -1.33 [-5.13, +2.46] | 3.80 | 31.00 | UNINFORMATIVE | INDETERMINATE | 8.80 |
| validate_domain | 74.4% | +1.67 [-2.14, +5.47] | 3.80 | 9.17 | UNINFORMATIVE | INDETERMINATE | 8.80 |
| validate_problem | 74.5% | +0.83 [-1.36, +3.02] | 2.19 | 1.00 | ELIGIBLE | EQUIVALENT | 7.19 |
| validate_plan | 90.5% | -0.33 [-1.61, +0.94] | 1.27 | 0.60 | UNINFORMATIVE | EQUIVALENT | 6.27 |
| simulate | 36.3% | -1.00 [-6.69, +4.69] | 5.69 | 36.00 | UNINFORMATIVE | INDETERMINATE ⚠ | 10.69 |


- ELIGIBLE family: validate_problem
- Intersection-union: the conjunctive equivalence claim needs no α correction and none is applied. Holm covers the ELIGIBLE family only, for the affirmative non-equivalence claim. Family membership is frozen by the pre-registered rule and is never re-picked after seeing Δ̂.

**Mechanism (secondary — never gates or revises the verdict).**

- label: VOID

| component | anchor | steered | Δ̂ [90% CI] |
|---|---:|---:|---|
| TRUNCATED_LOSS | 0.00% | 0.00% | +0.00 [+0.00, +0.00] |
| CHANNEL_FORMAT | 1.36% | 0.81% | -0.55 [-0.98, -0.12] |
| CONTENT | 2.83% | 3.44% | +0.61 [+0.15, +1.08] |
| APPARATUS | 17.48% | 17.54% | +0.07 [-0.91, +1.04] |

- ΣΔ components +0.13pp vs −Δ̂ +0.13pp (domain clustering, the footing the components are computed on; residual +0.000pp)
- M1 directive echo, ARM DIFFERENCE: +0.00pp (anchor 0.00% → steered 0.00%)
- M2 budget: done_reason=length 3.2% → 3.0%; mean completion tokens nan → nan; at-cap 0.0% → 0.0%
- censored at snapshot cap (reported separately, folded into neither side): anchor 1.29%, steered 1.01%

  > The four components partition Δ̂ exactly (ΣΔ = −Δ̂): this is an accounting split with CIs, not two independent measurements. Δtruncation must not be presented as corroborating ΔTRUNCATED-LOSS — they are the same rows.
  > APPARATUS share 17.48% in the anchor arm exceeds 1% — this cell's mechanism read is VOID.
  > APPARATUS share 17.54% in the steered arm exceeds 1% — this cell's mechanism read is VOID.
  > M1 is an ARM DIFFERENCE, never an absolute: base rate in the roster neutral no-tools arms is 0/27,360, but that anchor is measured on 500-char snapshots and is a specificity floor. M1 is a lower bound on at-cap rows and is anti-correlated with displacement by construction, so a depressed M1 inside a displacement-dominated cell may not be read as 'no directive echo'.

## slurm_vllm_qwen3_6_35b_on_no-tools_ntster-h4

- complete: 9,120 rows, 1,520/variant, per-(task, variant) shape exact

**Pooled (primary).** anchor 83.75% (3819/4560), steered 83.31% (3799/4560), 4,560 matched pairs.

| interval | Δ̂ [90% CI] | half-width |
|---|---|---:|
| domain | -0.44 [-1.34, +0.46] | 0.90pp |
| problem | +0.49 [-1.37, +2.35] | 1.86pp |
| governing | +0.49 [-1.37, +2.35] | 1.86pp |
| bootstrap_domain | -0.44 [-1.32, +0.35] | 0.83pp |
| newcombe_unpaired | -0.44 [-1.72, +0.84] | 1.28pp |

- row-level pooled Δ: -0.44pp (cluster-mean vs row-level agree when clusters are balanced)
- label: **EQUIVALENT**
- MDE (|Δ| needed to FAIL): 6.86pp

**Per task.** Classification is assigned mechanically from the anchor and the realized precision, before the label is read.

| task | anchor | Δ̂ governing | half-width | F | class | label | MDE |
|---|---:|---|---:|---:|---|---|---:|
| solve | 42.0% | -7.67 [-14.11, -1.23] | 6.44 | 26.00 | UNINFORMATIVE | INDETERMINATE ⚠ | 11.44 |
| validate_domain | 81.4% | -2.50 [-7.50, +2.50] | 5.00 | 5.83 | UNINFORMATIVE | INDETERMINATE ⚠ | 10.00 |
| validate_problem | 76.0% | +1.17 [-0.36, +2.70] | 1.53 | 1.50 | ELIGIBLE | EQUIVALENT | 6.53 |
| validate_plan | 92.6% | -0.30 [-1.10, +0.50] | 0.80 | 1.20 | UNINFORMATIVE | EQUIVALENT | 5.80 |
| simulate | 55.0% | +4.67 [-1.13, +10.47] | 5.80 | 19.00 | UNINFORMATIVE | INDETERMINATE ⚠ | 10.80 |


- ELIGIBLE family: validate_problem
- Intersection-union: the conjunctive equivalence claim needs no α correction and none is applied. Holm covers the ELIGIBLE family only, for the affirmative non-equivalence claim. Family membership is frozen by the pre-registered rule and is never re-picked after seeing Δ̂.

**Mechanism (secondary — never gates or revises the verdict).**

- label: VOID

| component | anchor | steered | Δ̂ [90% CI] |
|---|---:|---:|---|
| TRUNCATED_LOSS | 0.00% | 0.00% | +0.00 [+0.00, +0.00] |
| CHANNEL_FORMAT | 1.10% | 0.83% | -0.26 [-0.52, -0.00] |
| CONTENT | 1.40% | 1.38% | -0.02 [-0.29, +0.24] |
| APPARATUS | 13.75% | 14.47% | +0.72 [+0.01, +1.44] |

- ΣΔ components +0.44pp vs −Δ̂ +0.44pp (domain clustering, the footing the components are computed on; residual -0.000pp)
- M1 directive echo, ARM DIFFERENCE: +0.00pp (anchor 0.00% → steered 0.00%)
- M2 budget: done_reason=length 4.9% → 5.3%; mean completion tokens nan → nan; at-cap 0.0% → 0.0%
- censored at snapshot cap (reported separately, folded into neither side): anchor 1.12%, steered 1.18%

  > The four components partition Δ̂ exactly (ΣΔ = −Δ̂): this is an accounting split with CIs, not two independent measurements. Δtruncation must not be presented as corroborating ΔTRUNCATED-LOSS — they are the same rows.
  > APPARATUS share 13.75% in the anchor arm exceeds 1% — this cell's mechanism read is VOID.
  > APPARATUS share 14.47% in the steered arm exceeds 1% — this cell's mechanism read is VOID.
  > M1 is an ARM DIFFERENCE, never an absolute: base rate in the roster neutral no-tools arms is 0/27,360, but that anchor is measured on 500-char snapshots and is a specificity floor. M1 is a lower bound on at-cap rows and is anti-correlated with displacement by construction, so a depressed M1 inside a displacement-dominated cell may not be read as 'no directive echo'.

---

**Control conservatism (§3.5).** Under `with_tools=False` the system prompt is always `WITHOUT_TOOLS_SYSTEM_BY_TASK[task]` regardless of variant, which states that validation tools are not available, while the steered v14-16 user text tells the model to use a named tool. The control therefore removes both the tool and its stated availability, which **biases H4 toward PASS** — a PASS is weaker evidence than an unqualified reading would suggest.

**Serving nondeterminism** at T=0 is unbounded by our corpora: decoding is greedy and unseeded, and no prompt was ever measured twice under one apparatus. Registered as a stated limitation, not a number.

