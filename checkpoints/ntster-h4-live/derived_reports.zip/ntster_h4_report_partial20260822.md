# nt-ster H4 — confirmatory contrast

Margin ±5pp · 90% intervals · surface = delivered · bootstrap B=10,000 · GT gate `6af57125bde3`

Δ̂ = steered − anchor. The governing interval is the **wider** of the domain (k=20) and problem-instance (k=100) clusterings.

## Paper-level branch: **INCONCLUSIVE**

Not all units PASS and no ELIGIBLE FAIL.

Cells: slurm_vllm_Qwen3_5_9B_on_no-tools_ntster-h4, slurm_vllm_qwen3_6_35b_on_no-tools_ntster-h4

## Verdict vector

| cell | anchor | steered | Δ̂ governing | F | verdict |
|---|---:|---:|---|---:|---|
| slurm_vllm_Qwen3_5_9B_off_no-tools_ntster-h4 | 66.2% | 67.2% | -0.18 [-1.89, +1.52] | 1.12 | **PASS** |
| slurm_vllm_Qwen3_5_9B_on_no-tools_ntster-h4 | — | — | — | — | INCONCLUSIVE (incomplete cell) |
| slurm_vllm_gemma4_26b-a4b_off_no-tools_ntster-h4 | 78.2% | 78.6% | +0.52 [-0.95, +1.99] | 2.76 | **PASS** |
| slurm_vllm_qwen3_6_35b_off_no-tools_ntster-h4 | 78.3% | 78.2% | +1.34 [-0.40, +3.08] | 2.24 | **PASS** |
| slurm_vllm_qwen3_6_35b_on_no-tools_ntster-h4 | — | — | — | — | INCONCLUSIVE (incomplete cell) |

## slurm_vllm_Qwen3_5_9B_off_no-tools_ntster-h4

- complete: 9,120 rows, 1,520/variant, per-(task, variant) shape exact

**Pooled (primary).** anchor 66.18% (3018/4560), steered 67.24% (3066/4560), 4,560 matched pairs.

| interval | Δ̂ [90% CI] | half-width |
|---|---|---:|
| domain | +1.05 [-0.13, +2.24] | 1.18pp |
| problem | -0.18 [-1.89, +1.52] | 1.70pp |
| governing | -0.18 [-1.89, +1.52] | 1.70pp |
| bootstrap_domain | +1.05 [-0.07, +2.11] | 1.09pp |
| newcombe_unpaired | +1.05 [-0.57, +2.68] | 1.62pp |

- row-level pooled Δ: +1.05pp (cluster-mean vs row-level agree when clusters are balanced)
- label: **EQUIVALENT**
- MDE (|Δ| needed to FAIL): 6.70pp

**Per task.** Classification is assigned mechanically from the anchor and the realized precision, before the label is read.

| task | anchor | Δ̂ governing | half-width | F | class | label | MDE |
|---|---:|---|---:|---:|---|---|---:|
| solve | 10.3% | -1.67 [-4.89, +1.56] | 3.23 | 28.00 | UNINFORMATIVE | EQUIVALENT | 8.23 |
| validate_domain | 25.3% | +4.17 [-0.07, +8.40] | 4.23 | 14.17 | UNINFORMATIVE | INDETERMINATE | 9.23 |
| validate_problem | 66.3% | +1.33 [-1.72, +4.39] | 3.06 | 4.50 | ELIGIBLE | EQUIVALENT | 8.06 |
| validate_plan | 79.8% | +0.63 [-1.24, +2.50] | 1.87 | 1.40 | ELIGIBLE | EQUIVALENT | 6.87 |
| simulate | 34.7% | +3.67 [-2.56, +9.90] | 6.23 | 21.00 | UNINFORMATIVE | INDETERMINATE ⚠ | 11.23 |


- ELIGIBLE family: validate_problem, validate_plan
- Intersection-union: the conjunctive equivalence claim needs no α correction and none is applied. Holm covers the ELIGIBLE family only, for the affirmative non-equivalence claim. Family membership is frozen by the pre-registered rule and is never re-picked after seeing Δ̂.

**Mechanism (secondary — never gates or revises the verdict).**

- label: VOID

| component | anchor | steered | Δ̂ [90% CI] |
|---|---:|---:|---|
| TRUNCATED_LOSS | 0.00% | 0.00% | +0.00 [+0.00, +0.00] |
| CHANNEL_FORMAT | 0.81% | 0.75% | -0.07 [-0.25, +0.12] |
| CONTENT | 3.49% | 3.31% | -0.18 [-0.62, +0.27] |
| APPARATUS | 29.52% | 28.71% | -0.81 [-2.07, +0.45] |

- ΣΔ components -1.05pp vs −Δ̂ -1.05pp (domain clustering, the footing the components are computed on; residual -0.000pp)
- M1 directive echo, ARM DIFFERENCE: +0.00pp (anchor 0.00% → steered 0.00%)
- M2 budget: done_reason=length 6.4% → 5.8%; mean completion tokens nan → nan; at-cap 0.0% → 0.0%
- censored at snapshot cap (reported separately, folded into neither side): anchor 1.75%, steered 1.58%

  > The four components partition Δ̂ exactly (ΣΔ = −Δ̂): this is an accounting split with CIs, not two independent measurements. Δtruncation must not be presented as corroborating ΔTRUNCATED-LOSS — they are the same rows.
  > APPARATUS share 29.52% in the anchor arm exceeds 1% — this cell's mechanism read is VOID.
  > APPARATUS share 28.71% in the steered arm exceeds 1% — this cell's mechanism read is VOID.
  > M1 is an ARM DIFFERENCE, never an absolute: base rate in the roster neutral no-tools arms is 0/27,360, but that anchor is measured on 500-char snapshots and is a specificity floor. M1 is a lower bound on at-cap rows and is anti-correlated with displacement by construction, so a depressed M1 inside a displacement-dominated cell may not be read as 'no directive echo'.

## slurm_vllm_Qwen3_5_9B_on_no-tools_ntster-h4

- row count 3,824 != expected 9,120 over variants [11, 12, 13, 14, 15, 16]
- variant v11: 638 rows != 1,520
- variant v12: 638 rows != 1,520
- variant v13: 637 rows != 1,520
- variant v14: 637 rows != 1,520
- variant v15: 637 rows != 1,520
- variant v16: 637 rows != 1,520
- (validate_plan, v11): 218 rows != 1,000
- (validate_plan, v12): 218 rows != 1,000
- (validate_plan, v13): 217 rows != 1,000
- (validate_plan, v14): 217 rows != 1,000
- (validate_plan, v15): 217 rows != 1,000
- (validate_plan, v16): 217 rows != 1,000
- (simulate, v11): 0 rows != 100
- (simulate, v12): 0 rows != 100
- (simulate, v13): 0 rows != 100
- (simulate, v14): 0 rows != 100
- (simulate, v15): 0 rows != 100
- (simulate, v16): 0 rows != 100
- snapshot_cap [500] != [16384] — detect_cap returns 500 for any cell whose max response length is ≤500, so this cell's censor branches are not trustworthy (§3.1)
- Incomplete cells are INCONCLUSIVE and are NOT analysed on the surviving subset (§3.1); the missing keys must be re-run to completion.

## slurm_vllm_gemma4_26b-a4b_off_no-tools_ntster-h4

- complete: 9,120 rows, 1,520/variant, per-(task, variant) shape exact

**Pooled (primary).** anchor 78.16% (3564/4560), steered 78.64% (3586/4560), 4,560 matched pairs.

| interval | Δ̂ [90% CI] | half-width |
|---|---|---:|
| domain | +0.48 [-0.23, +1.20] | 0.71pp |
| problem | +0.52 [-0.95, +1.99] | 1.47pp |
| governing | +0.52 [-0.95, +1.99] | 1.47pp |
| bootstrap_domain | +0.48 [-0.20, +1.10] | 0.65pp |
| newcombe_unpaired | +0.48 [-0.94, +1.90] | 1.42pp |

- row-level pooled Δ: +0.48pp (cluster-mean vs row-level agree when clusters are balanced)
- label: **EQUIVALENT**
- MDE (|Δ| needed to FAIL): 6.47pp

**Per task.** Classification is assigned mechanically from the anchor and the realized precision, before the label is read.

| task | anchor | Δ̂ governing | half-width | F | class | label | MDE |
|---|---:|---|---:|---:|---|---|---:|
| solve | 10.3% | -4.00 [-7.68, -0.32] | 3.68 | 14.00 | UNINFORMATIVE | INDETERMINATE | 8.68 |
| validate_domain | 79.2% | -1.39 [-4.86, +2.09] | 3.48 | 5.00 | UNINFORMATIVE | EQUIVALENT | 8.48 |
| validate_problem | 77.7% | -0.50 [-2.88, +1.88] | 2.38 | 4.00 | ELIGIBLE | EQUIVALENT | 7.38 |
| validate_plan | 88.3% | +0.63 [-0.46, +1.73] | 1.10 | 2.50 | ELIGIBLE | EQUIVALENT | 6.10 |
| simulate | 44.3% | +7.67 [+3.22, +12.11] | 4.45 | 34.00 | UNINFORMATIVE | INDETERMINATE | 9.45 |


- ELIGIBLE family: validate_problem, validate_plan
- Intersection-union: the conjunctive equivalence claim needs no α correction and none is applied. Holm covers the ELIGIBLE family only, for the affirmative non-equivalence claim. Family membership is frozen by the pre-registered rule and is never re-picked after seeing Δ̂.

**Mechanism (secondary — never gates or revises the verdict).**

- label: VOID

| component | anchor | steered | Δ̂ [90% CI] |
|---|---:|---:|---|
| TRUNCATED_LOSS | 0.00% | 0.00% | +0.00 [+0.00, +0.00] |
| CHANNEL_FORMAT | 2.15% | 1.71% | -0.44 [-0.67, -0.21] |
| CONTENT | 1.51% | 1.45% | -0.07 [-0.31, +0.18] |
| APPARATUS | 18.18% | 18.20% | +0.02 [-0.71, +0.75] |

- ΣΔ components -0.48pp vs −Δ̂ -0.48pp (domain clustering, the footing the components are computed on; residual +0.000pp)
- M1 directive echo, ARM DIFFERENCE: +0.00pp (anchor 0.00% → steered 0.00%)
- M2 budget: done_reason=length 3.3% → 3.1%; mean completion tokens nan → nan; at-cap 0.0% → 0.0%
- censored at snapshot cap (reported separately, folded into neither side): anchor 1.49%, steered 1.45%

  > The four components partition Δ̂ exactly (ΣΔ = −Δ̂): this is an accounting split with CIs, not two independent measurements. Δtruncation must not be presented as corroborating ΔTRUNCATED-LOSS — they are the same rows.
  > APPARATUS share 18.18% in the anchor arm exceeds 1% — this cell's mechanism read is VOID.
  > APPARATUS share 18.20% in the steered arm exceeds 1% — this cell's mechanism read is VOID.
  > M1 is an ARM DIFFERENCE, never an absolute: base rate in the roster neutral no-tools arms is 0/27,360, but that anchor is measured on 500-char snapshots and is a specificity floor. M1 is a lower bound on at-cap rows and is anti-correlated with displacement by construction, so a depressed M1 inside a displacement-dominated cell may not be read as 'no directive echo'.

## slurm_vllm_qwen3_6_35b_off_no-tools_ntster-h4

- complete: 9,120 rows, 1,520/variant, per-(task, variant) shape exact

**Pooled (primary).** anchor 78.33% (3572/4560), steered 78.20% (3566/4560), 4,560 matched pairs.

| interval | Δ̂ [90% CI] | half-width |
|---|---|---:|
| domain | -0.13 [-1.16, +0.89] | 1.02pp |
| problem | +1.34 [-0.40, +3.08] | 1.74pp |
| governing | +1.34 [-0.40, +3.08] | 1.74pp |
| bootstrap_domain | -0.13 [-1.07, +0.81] | 0.94pp |
| newcombe_unpaired | -0.13 [-1.55, +1.29] | 1.42pp |

- row-level pooled Δ: -0.13pp (cluster-mean vs row-level agree when clusters are balanced)
- label: **EQUIVALENT**
- MDE (|Δ| needed to FAIL): 6.74pp

**Per task.** Classification is assigned mechanically from the anchor and the realized precision, before the label is read.

| task | anchor | Δ̂ governing | half-width | F | class | label | MDE |
|---|---:|---|---:|---:|---|---|---:|
| solve | 10.7% | -1.33 [-5.13, +2.46] | 3.80 | 31.00 | UNINFORMATIVE | INDETERMINATE | 8.80 |
| validate_domain | 74.4% | +1.67 [-2.14, +5.47] | 3.80 | 9.17 | UNINFORMATIVE | INDETERMINATE | 8.80 |
| validate_problem | 74.5% | +0.83 [-1.36, +3.02] | 2.19 | 1.00 | ELIGIBLE | EQUIVALENT | 7.19 |
| validate_plan | 90.5% | -0.33 [-1.61, +0.94] | 1.27 | 0.60 | UNINFORMATIVE | EQUIVALENT | 6.27 |
| simulate | 36.3% | -1.00 [-6.69, +4.69] | 5.69 | 36.00 | UNINFORMATIVE | INDETERMINATE ⚠ | 10.69 |


- ELIGIBLE family: validate_problem
- Intersection-union: the conjunctive equivalence claim needs no α correction and none is applied. Holm covers the ELIGIBLE family only, for the affirmative non-equivalence claim. Family membership is frozen by the pre-registered rule and is never re-picked after seeing Δ̂.

**Mechanism (secondary — never gates or revises the verdict).**

- label: VOID

| component | anchor | steered | Δ̂ [90% CI] |
|---|---:|---:|---|
| TRUNCATED_LOSS | 0.00% | 0.00% | +0.00 [+0.00, +0.00] |
| CHANNEL_FORMAT | 1.36% | 0.81% | -0.55 [-0.98, -0.12] |
| CONTENT | 2.83% | 3.44% | +0.61 [+0.15, +1.08] |
| APPARATUS | 17.48% | 17.54% | +0.07 [-0.91, +1.04] |

- ΣΔ components +0.13pp vs −Δ̂ +0.13pp (domain clustering, the footing the components are computed on; residual +0.000pp)
- M1 directive echo, ARM DIFFERENCE: +0.00pp (anchor 0.00% → steered 0.00%)
- M2 budget: done_reason=length 3.2% → 3.0%; mean completion tokens nan → nan; at-cap 0.0% → 0.0%
- censored at snapshot cap (reported separately, folded into neither side): anchor 1.29%, steered 1.01%

  > The four components partition Δ̂ exactly (ΣΔ = −Δ̂): this is an accounting split with CIs, not two independent measurements. Δtruncation must not be presented as corroborating ΔTRUNCATED-LOSS — they are the same rows.
  > APPARATUS share 17.48% in the anchor arm exceeds 1% — this cell's mechanism read is VOID.
  > APPARATUS share 17.54% in the steered arm exceeds 1% — this cell's mechanism read is VOID.
  > M1 is an ARM DIFFERENCE, never an absolute: base rate in the roster neutral no-tools arms is 0/27,360, but that anchor is measured on 500-char snapshots and is a specificity floor. M1 is a lower bound on at-cap rows and is anti-correlated with displacement by construction, so a depressed M1 inside a displacement-dominated cell may not be read as 'no directive echo'.

## slurm_vllm_qwen3_6_35b_on_no-tools_ntster-h4

- snapshot_cap [500] != [16384] — detect_cap returns 500 for any cell whose max response length is ≤500, so this cell's censor branches are not trustworthy (§3.1)
- Incomplete cells are INCONCLUSIVE and are NOT analysed on the surviving subset (§3.1); the missing keys must be re-run to completion.

---

**Control conservatism (§3.5).** Under `with_tools=False` the system prompt is always `WITHOUT_TOOLS_SYSTEM_BY_TASK[task]` regardless of variant, which states that validation tools are not available, while the steered v14-16 user text tells the model to use a named tool. The control therefore removes both the tool and its stated availability, which **biases H4 toward PASS** — a PASS is weaker evidence than an unqualified reading would suggest.

**Serving nondeterminism** at T=0 is unbounded by our corpora: decoding is greedy and unseeded, and no prompt was ever measured twice under one apparatus. Registered as a stated limitation, not a number.

